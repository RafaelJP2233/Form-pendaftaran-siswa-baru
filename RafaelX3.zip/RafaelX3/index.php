<?php
$names = $_POST['nama'];
$temlahir = $_POST['tempatlahir'];
$tanggal = $_POST['tanggal'];
$bulan = $_POST['bulan'];
$tahun = $_POST['tahun'];
$kelamin = $_POST["kelamin"];
$asal = $_POST['asal'];
$nilai = $_POST['nilai'];

echo "<h2>Terimakasih $names sudah mengisi form pendaftaran</h2>";

echo "<p>Nama Lengkap: $names</p>";
echo "<p>Tempat lahir: $temlahir</p>";
echo "<p>Tanggal Lahir: $tanggal-$bulan-$tahun</p>";
echo "<p>Jenis Kelamin: $kelamin</p>";
echo "<p>Asal Sekolah: $asal</p>";
echo "<p>Nilai UAN: $nilai</p>";
?>